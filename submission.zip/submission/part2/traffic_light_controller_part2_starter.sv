// traffic light controller solution stretch
// CSE140L 3-street, 20-state version, ew str/left decouple
// inserts all-red after each yellow
// uses enumerated variables for states and for red-yellow-green
// 5 after traffic, 10 max cycles for green when other traffic present
import light_package ::*;           // defines red, yellow, green

// same as Harris & Harris 4-state, but we have added two all-reds
module traffic_light_controller(
  input clk, reset, e_str_sensor, w_str_sensor, e_left_sensor, 
        w_left_sensor, ns_sensor,             // traffic sensors, east-west str, east-west left, north-south 
  output colors e_str_light, w_str_light, e_left_light, w_left_light, ns_light);     // traffic lights, east-west str, east-west left, north-south

  logic s, sb, e, eb, w, wb, l, lb, n, nb;	 // shorthand for traffic combinations:

  assign s  = e_str_sensor || w_str_sensor;					 // str E or W
  assign sb = e_left_sensor || w_left_sensor || ns_sensor;			     // 3 directions which conflict with s
  assign e  = e_left_sensor || e_str_sensor;					     // E str or L
  assign eb = w_left_sensor || w_str_sensor || ns_sensor;			 // conflicts with e
  assign w  = w_left_sensor || w_str_sensor;
  assign wb = e_left_sensor || e_str_sensor || ns_sensor;
  assign l  = e_left_sensor || w_left_sensor;
  assign lb = e_str_sensor || w_str_sensor || ns_sensor;
  assign n  = ns_sensor;
  assign nb = s || l; 

// 20 suggested states, 4 per direction   Y, Z = easy way to get 2-second yellows
// HRRRR = red-red following ZRRRR; ZRRRR = second yellow following YRRRR; 
// RRRRH = red-red following RRRRZ;
  typedef enum {GRRRR, YRRRR, ZRRRR, HRRRR, 	           // ES+WS
  	            RGRRR, RYRRR, RZRRR, RHRRR, 			   // EL+ES
	            RRGRR, RRYRR, RRZRR, RRHRR,				   // WL+WS
	            RRRGR, RRRYR, RRRZR, RRRHR, 			   // WL+EL
	            RRRRG, RRRRY, RRRRZ, RRRRH} tlc_states;    // NS
	tlc_states    present_state, next_state;
	integer ctr5, next_ctr5,       //  5 sec timeout when my traffic goes away
			ctr10, next_ctr10;     // 10 sec limit when other traffic presents

// sequential part of our state machine (register between C1 and C2 in Harris & Harris Moore machine diagram
// combinational part will reset or increment the counters and figure out the next_state
  always_ff @(posedge clk)
	if(reset) begin
	  present_state <= RRRRH;
	  ctr5          <= 0;
	  ctr10         <= 0;
	end  
	else begin
	  present_state <= next_state;
	  ctr5          <= next_ctr5;
	  ctr10         <= next_ctr10;
	end  

// combinational part of state machine ("C1" block in the Harris & Harris Moore machine diagram)
// default needed because only 6 of 8 possible states are defined/used
  always_comb begin
	next_state = RRRRH;                            // default to reset state
	next_ctr5  = 0; 							   // default: reset counters
	next_ctr10 = 0;
	case(present_state)
/* ************* Fill in the case statements ************** */
		// EWS light
		GRRRR: begin /* fill in the guts
			   build on part 1
			   round-robin priority for four other direcions
                */
			if(ctr5 == 4 || ctr10 == 9) begin
			    next_state = YRRRR;
        	end else if(!s && ctr5 == 0) begin // there is a gap in this street --> begin ctr5
            	next_state = GRRRR;
            	next_ctr5  = ctr5 + 1;
				next_ctr10 = ctr10 + 1;
        	end else if (ctr5 > 0 && ctr10 == 0) begin  // ctr5 started --> keep incrementing it
				next_state = GRRRR;
				next_ctr5 = ctr5 + 1;
			end else if(ctr10 == 0 && sb) begin // there is no gap BUT there is traffice waiting on other lights --> begin ctr10
				next_state = GRRRR;
				next_ctr10 = ctr10 + 1;
			end else if(ctr10 > 0 && ctr5 == 0) begin  // ctr10 started --> keep incrementing it 
				next_state = GRRRR;
				next_ctr10 = ctr10 + 1;
			end else if(ctr10 > 0 && ctr5 > 0) begin // if both counters started --> keep incrementing both
				next_state = GRRRR;
				next_ctr10 = ctr10 + 1;
				next_ctr5 = ctr5 + 1;
			end else begin
				next_state = GRRRR; // no gap in traffic NOR traffic waiting on other lights --> keep giving green light
			end
	    end      
		YRRRR: next_state = ZRRRR;  // 2nd yellow
		ZRRRR: next_state = HRRRR;  // all red lights
		HRRRR: begin
			// priority --> EL_ES > WL_WS > EWL > NS > EWS 
			// finish priority doctrine
			if(e) begin
				next_state = RGRRR;  
			end else if(w) begin
				next_state = RRGRR;  
			end else if(l) begin
				next_state = RRRGR;  
			end else if(n) begin
				next_state = RRRRG;  
			end else if(s) begin
				next_state = GRRRR;  
			end else begin
				next_state = HRRRR; // stay put
			end      
		end

		// ES_EL light
		RGRRR: begin 		                                 // EL+ES green
              // ** fill in the guts **
			if(ctr5 == 4 || ctr10 == 9) begin
			    next_state = RYRRR;
        	end else if(!e && ctr5 == 0) begin // there is a gap in this street --> begin ctr5
            	next_state = RGRRR;
            	next_ctr5  = ctr5 + 1;
				next_ctr10 = ctr10 + 1;
        	end else if (ctr5 > 0 && ctr10 == 0) begin  // ctr5 started --> keep incrementing it
				next_state = RGRRR;
				next_ctr5 = ctr5 + 1;
			end else if(ctr10 == 0 && eb) begin // there is no gap BUT there is traffice waiting on other lights --> begin ctr10
				next_state = RGRRR;
				next_ctr10 = ctr10 + 1;
			end else if(ctr10 > 0 && ctr5 == 0) begin  // ctr10 started --> keep incrementing it 
				next_state = RGRRR;
				next_ctr10 = ctr10 + 1;
			end else if(ctr10 > 0 && ctr5 > 0) begin // if both counters started --> keep incrementing both
				next_state = RGRRR;
				next_ctr10 = ctr10 + 1;
				next_ctr5 = ctr5 + 1;
			end else begin
				next_state = RGRRR; // no gap in traffic NOR traffic waiting on other lights --> keep giving green light
			end
	    end
		RYRRR: next_state = RZRRR;
		RZRRR: next_state = RHRRR;
		RHRRR: begin
			// WL_WS > EWL > NS > EWS > EL_ES
            // finish priority doctrine
			if(w) begin
				next_state = RRGRR;  
			end else if(l) begin
				next_state = RRRGR;  
			end else if(n) begin
				next_state = RRRRG;  
			end else if(s) begin
				next_state = GRRRR;  
			end else if(e) begin
				next_state = RGRRR;  
			end else begin
				next_state = RHRRR; // stay put
			end 
    	end

		// WS_WL light
	  	RRGRR: begin 
	        // ** fill in the guts, etc **
			if(ctr5 == 4 || ctr10 == 9) begin
			    next_state = RRYRR;
        	end else if(!w && ctr5 == 0) begin // there is a gap in this street --> begin ctr5
            	next_state = RRGRR;
            	next_ctr5  = ctr5 + 1;
				next_ctr10 = ctr10 + 1;
        	end else if (ctr5 > 0 && ctr10 == 0) begin  // ctr5 started --> keep incrementing it
				next_state = RRGRR;
				next_ctr5 = ctr5 + 1;
			end else if(ctr10 == 0 && wb) begin // there is no gap BUT there is traffice waiting on other lights --> begin ctr10
				next_state = RRGRR;
				next_ctr10 = ctr10 + 1;
			end else if(ctr10 > 0 && ctr5 == 0) begin  // ctr10 started --> keep incrementing it 
				next_state = RRGRR;
				next_ctr10 = ctr10 + 1;
			end else if(ctr10 > 0 && ctr5 > 0) begin // if both counters started --> keep incrementing both
				next_state = RRGRR;
				next_ctr10 = ctr10 + 1;
				next_ctr5 = ctr5 + 1;
			end else begin
				next_state = RRGRR; // no gap in traffic NOR traffic waiting on other lights --> keep giving green light
			end


	 	end
		RRYRR: next_state = RRZRR;
		RRZRR: next_state = RRHRR;
		RRHRR: begin
			// EWL > NS > EWS > EL_ES > WL_WS
			// finish priority doctrine
			if(l) begin
				next_state = RRRGR;  
			end else if(n) begin
				next_state = RRRRG;  
			end else if(s) begin
				next_state = GRRRR;  
			end else if(e) begin
				next_state = RGRRR;  
			end else if(w) begin
				next_state = RRGRR;  
			end else begin
				next_state = RRHRR; // stay put
			end 
		end

		// EWL light
		RRRGR: begin
			// ** fill in the guts, etc **
			if(ctr5 == 4 || ctr10 == 9) begin
			    next_state = RRRYR;
        	end else if(!l && ctr5 == 0) begin // there is a gap in this street --> begin ctr5
            	next_state = RRRGR;
            	next_ctr5  = ctr5 + 1;
				next_ctr10 = ctr10 + 1;
        	end else if (ctr5 > 0 && ctr10 == 0) begin  // ctr5 started --> keep incrementing it
				next_state = RRRGR;
				next_ctr5 = ctr5 + 1;
			end else if(ctr10 == 0 && lb) begin // there is no gap BUT there is traffice waiting on other lights --> begin ctr10
				next_state = RRRGR;
				next_ctr10 = ctr10 + 1;
			end else if(ctr10 > 0 && ctr5 == 0) begin  // ctr10 started --> keep incrementing it 
				next_state = RRRGR;
				next_ctr10 = ctr10 + 1;
			end else if(ctr10 > 0 && ctr5 > 0) begin // if both counters started --> keep incrementing both
				next_state = RRRGR;
				next_ctr10 = ctr10 + 1;
				next_ctr5 = ctr5 + 1;
			end else begin
				next_state = RRRGR; // no gap in traffic NOR traffic waiting on other lights --> keep giving green light
			end

			
		end
		RRRYR: next_state = RRRZR;
		RRRZR: next_state = RRRHR;
		RRRHR: begin
			// NS > EWS > EL_ES > WL_WS > EWL
			// finish priority doctrine
			if(n) begin
				next_state = RRRRG;  
			end else if(s) begin
				next_state = GRRRR;  
			end else if(e) begin
				next_state = RGRRR;  
			end else if(w) begin
				next_state = RRGRR;  
			end else if(l) begin
				next_state = RRRGR;  
			end else begin
				next_state = RRRHR; // stay put
			end 
		end

		// NS light
		RRRRG: begin
			// ** fill in the guts, etc **
			if(ctr5 == 4 || ctr10 == 9) begin
			    next_state = RRRRY;
        	end else if(!n && ctr5 == 0) begin // there is a gap in this street --> begin ctr5
            	next_state = RRRRG;
            	next_ctr5  = ctr5 + 1;
				next_ctr10 = ctr10 + 1;
        	end else if (ctr5 > 0 && ctr10 == 0) begin  // ctr5 started --> keep incrementing it
				next_state = RRRRG;
				next_ctr5 = ctr5 + 1;
			end else if(ctr10 == 0 && nb) begin // there is no gap BUT there is traffice waiting on other lights --> begin ctr10
				next_state = RRRRG;
				next_ctr10 = ctr10 + 1;
			end else if(ctr10 > 0 && ctr5 == 0) begin  // ctr10 started --> keep incrementing it 
				next_state = RRRRG;
				next_ctr10 = ctr10 + 1;
			end else if(ctr10 > 0 && ctr5 > 0) begin // if both counters started --> keep incrementing both
				next_state = RRRRG;
				next_ctr10 = ctr10 + 1;
				next_ctr5 = ctr5 + 1;
			end else begin
				next_state = RRRRG; // no gap in traffic NOR traffic waiting on other lights --> keep giving green light
			end
		end
		RRRRY: next_state = RRRRZ;
		RRRRZ: next_state = RRRRH;
		RRRRH: begin
			// EWS > EL_ES > WL_WS > EWL > NS 
			// finish priority doctrine
			if(s) begin
				next_state = GRRRR;  
			end else if(e) begin
				next_state = RGRRR;  
			end else if(w) begin
				next_state = RRGRR;  
			end else if(l) begin
				next_state = RRRGR;  
			end else if(n) begin
				next_state = RRRRG;  
			end else begin
				next_state = RRRRH; // stay put
			end 
		end

      // ** fill in the guts to complete 5 sets of R Y Z H progressions **
	endcase
  end

// combination output driver  ("C2" block in the Harris & Harris Moore machine diagram)
	always_comb begin
	  e_str_light  = red;                // cover all red plus undefined cases
	  w_str_light  = red;				 // no need to list them below this block
	  e_left_light = red;
	  w_left_light = red;
	  ns_light     = red;
	  case(present_state)      // Moore machine
	  // ** fill in the guts for all 5 directions -- just the greens and yellows ** --> DONE
		GRRRR: begin
			e_str_light = green;
			w_str_light = green;
		end
		YRRRR,ZRRRR: begin
			e_str_light = yelllow;
			w_str_light = yellow;
		end
		RGRRR: begin
			e_str_light = green;
			e_left_light = green;
		end
		RYRRR,RZRRR: begin
			e_str_light = yellow;
			e_left_light = yellow;
		end
		RRGRR: begin
			w_str_light = green;
			w_left_light = green;
		end
		RRYRR,RRZRR: begin
			w_str_light = yellow;
			w_left_light = yellow;
		end
		RRRGR: begin
			e_left_light = green;
			w_left_light = green;
		end
		RRRYR,RRRZR: begin
			e_left_light = yellow;
			w_left_light = yellow;
		end
		RRRRG: begin
			ns_light = green;
		end
		RRRRY,RRRRZ: begin
			ns_light = yellow;
		end
	  endcase
	end

endmodule